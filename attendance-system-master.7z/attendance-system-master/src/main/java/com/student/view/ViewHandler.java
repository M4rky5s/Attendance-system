package com.student.view;

import java.io.IOException;

/**
 * @author Markas Alaburda
 */
public interface ViewHandler {
    void launchAttendanceWindow(int index) throws IOException;

    void launchStudentWindow() throws IOException;
}
