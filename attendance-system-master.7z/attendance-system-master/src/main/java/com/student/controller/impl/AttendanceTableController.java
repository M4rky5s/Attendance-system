package com.student.controller.impl;

import com.student.controller.AbstractTableController;
import com.student.model.Attendance;
import com.student.view.ViewHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

/**
 * @author Markas Alaburda
 */
public class AttendanceTableController extends AbstractTableController<Attendance> implements Table {
    private final Integer studentID;
    @FXML
    private TableColumn<Attendance, String> dateCol;
    @FXML
    private TableColumn<Attendance, String> presentCol;
    @FXML
    private TableColumn<Attendance, String> subjectCol;
    @FXML
    private DatePicker dpDate;
    @FXML
    private TextField tfSubject;
    @FXML
    private CheckBox chbPresent;
    @FXML
    private Button btnBack;
    @FXML
    private Button btnAdd;
    @FXML
    private Button btnEdit;
    @FXML
    private Button btnRemove;

    public AttendanceTableController(ViewHandler viewHandler, int index) {
        super(viewHandler);
        studentID = index;
    }

    @Override
    public EventHandler<ActionEvent> addRow() {
        return e -> {
            if ((list.stream().noneMatch(attend -> attend.getDate().equals(dpDate.getValue()) && attend.getSubject().equals(tfSubject.getText())))
                    && (dpDate.getValue() != null || !tfSubject.getText().isEmpty())) {
                list.add(new Attendance(dpDate.getValue(), chbPresent.isSelected(), tfSubject.getText()));
            }
            table.setItems(list);
            exportTable();
        };
    }

    @Override
    public EventHandler<ActionEvent> removeRow() {
        return e -> {
            list.remove(chosenObject);
            table.setItems(list);
            exportTable();
        };
    }

    @Override
    public void exportTable() {
        try {
            try (FileWriter fileWriter = new FileWriter(String.format("attendance/%dattendance.csv", studentID))) {
                fileWriter.append("Date,Present,Subject\n");
                for (Attendance attendance : list) {
                    fileWriter.append(attendance.getDate().toString())
                            .append(String.valueOf(','))
                            .append(String.valueOf(attendance.getPresent()))
                            .append(String.valueOf(','))
                            .append(attendance.getSubject()).append("\n");
                }
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public void importTable() throws RuntimeException {
        ObservableList<Attendance> attendances = FXCollections.observableArrayList();
        try (BufferedReader br = new BufferedReader(new FileReader(String.format("attendance/%dattendance.csv", studentID)))) {
            String line = br.readLine();
            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",", -1);
                LocalDate date = LocalDate.parse(fields[0]);
                boolean present = Boolean.parseBoolean(fields[1]);
                String subject = fields[2];

                Attendance attendance = new Attendance(date, present, subject);
                attendances.add(attendance);
            }
            list = attendances;
            table.setItems(list);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public EventHandler<ActionEvent> editRow() {
        return e -> {
            if (!list.isEmpty() && chosenObject != null) {
                list.remove(chosenObject);
                chosenObject = new Attendance(dpDate.getValue(), chbPresent.isSelected(), tfSubject.getText());
                list.add(chosenObject);
                table.setItems(list);
            }
        };
    }

    private void createNewFile() {
        String fileName = "attendance/" + studentID + "attendance.csv";
        File newAttendanceFile = new File(fileName);
        try {
            if (newAttendanceFile.exists()) {
                System.out.println("File already exists: " + fileName);
            } else {
                if (newAttendanceFile.getParentFile() != null && !newAttendanceFile.getParentFile().exists()) {
                    newAttendanceFile.getParentFile().mkdirs();
                }

                if (newAttendanceFile.createNewFile()) {
                    System.out.println("File created: " + fileName);
                } else {
                    System.out.println("Failed to create the file: " + fileName);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Error while creating the new file" + fileName, e);
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle bundle) {
        createNewFile();
        importTable();

        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        presentCol.setCellValueFactory(new PropertyValueFactory<>("present"));
        subjectCol.setCellValueFactory(new PropertyValueFactory<>("subject"));
        table.setRowFactory(tv -> {
            TableRow<Attendance> row = new TableRow<>();
            row.setOnMouseClicked(event -> {
                if (!row.isEmpty()) {
                    chosenObject = row.getItem();
                    dpDate.setValue(chosenObject.getDate());
                    tfSubject.setText(chosenObject.getSubject());
                    chbPresent.setSelected(chosenObject.getPresent());
                }
            });
            return row;
        });


        btnAdd.setOnAction(addRow());
        btnRemove.setOnAction(removeRow());
        btnEdit.setOnAction(editRow());

        btnBack.setOnAction(event -> {
            try {
                viewHandler.launchStudentWindow();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
        table.setItems(list);
    }
}
